package com.tyss.socialmedia.entity;

import lombok.Data;

@Data
public class Login {

//	private long mobileNumber;

	private String email;
	
	private String password;
}

