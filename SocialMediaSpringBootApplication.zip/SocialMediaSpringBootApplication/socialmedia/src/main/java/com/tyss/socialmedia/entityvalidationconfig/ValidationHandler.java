package com.tyss.socialmedia.entityvalidationconfig;

import java.util.HashMap;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ValidationHandler {
	@ExceptionHandler(ConstraintViolationException.class)
	protected ResponseEntity<Object> handleExceptionInternal(
			ConstraintViolationException exConstraintViolationException) {
		Map<String, String> map = new HashMap<String, String>();
		exConstraintViolationException.getConstraintViolations().stream().forEach(x -> {
			map.put("error: ", x.getMessage());
		});
		return new ResponseEntity<Object>(map, HttpStatus.BAD_REQUEST);
	}
}
