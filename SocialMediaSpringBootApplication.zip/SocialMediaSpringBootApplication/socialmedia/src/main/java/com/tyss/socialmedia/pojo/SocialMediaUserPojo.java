package com.tyss.socialmedia.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SocialMediaUserPojo {

	private int userId;

	private String userName;

	private String password;

	private String firstName;

	private String lastName;

	private String fullName = firstName + " " + lastName;

	private String mobileNumber;

	private String email;

	private String gender;

	private boolean enabled;

	private String verficationCode;
}
