package com.tyss.socialmedia.pojo;

import java.util.List;

import lombok.Data;

@Data
public class DataPojo {

	private String email;
	
	private List<FollowingPojo> followings;
}
