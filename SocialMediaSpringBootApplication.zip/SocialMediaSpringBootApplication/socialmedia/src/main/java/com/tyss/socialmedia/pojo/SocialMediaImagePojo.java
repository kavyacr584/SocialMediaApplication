package com.tyss.socialmedia.pojo;

import java.util.List;

import com.tyss.socialmedia.entity.SocialMediaImages;

import lombok.Data;

@Data
public class SocialMediaImagePojo {

	private int userId;

	private String userName;

	private String firstName;

	private String lastName;

	private String fullName = firstName + " " + lastName;

	private long mobileNumber;

	private String email;

	private String gender;

	private List<SocialMediaImages> media;

}
